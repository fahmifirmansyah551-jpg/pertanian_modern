const fs=require('fs'), path=require('path');
const f=path.join(__dirname,'..','www','index.html');
if(!fs.existsSync(f)){console.error('www/index.html tidak ditemukan');process.exit(1)}
console.log('TANI MODERN web OK: www/index.html siap dipublish.');
