# TANI MODERN v9

## Web / Netlify
Publish directory: `www`. Untuk upload manual ke Netlify, gunakan folder `www` atau ZIP project ini. Tidak perlu ekstraksi di HP jika upload ZIP melalui Netlify.

## Android
Di komputer dengan Node.js LTS dan Android Studio:
npm install
npx cap add android
npx cap sync android
npx cap open android
Kemudian Android Studio > Build > Generate Signed App Bundle / APK.

## iPhone
IPA membutuhkan macOS + Xcode:
npm install
npx cap add ios
npx cap sync ios
npx cap open ios

## Catatan produksi
Supabase, AI Vision, cuaca realtime, akun cloud, dan storage foto masih harus dihubungkan ke project/backend milik pemilik aplikasi. Jangan taruh service-role key atau secret AI di aplikasi.
