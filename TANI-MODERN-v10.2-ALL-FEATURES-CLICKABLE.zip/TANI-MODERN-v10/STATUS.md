# TANI MODERN — V10

Versi V10 dari project TANI MODERN, siap di-upload ke GitHub dan dibuild menjadi debug APK melalui GitHub Actions.

- Web app: `www/`
- Capacitor config: `capacitor.config.ts`
- Workflow build APK: `.github/workflows/build-apk.yml`
- Node: 20
- Java: 17
- Capacitor: 7.x


## V10.2
All visible navigation/buttons receive mobile-safe click handling; existing design is preserved.
